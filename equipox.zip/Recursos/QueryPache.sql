create table galeria(
	id int primary key AUTO_INCREMENT,
    nombre varchar(255),
    descripcion text,
    nombreCarpeta varchar(30)
)