<?php
define('TITULO','Equipos deportivos');
define('EQUIPO','Aguilas Cibaeñas');
define('LOGO','');
			