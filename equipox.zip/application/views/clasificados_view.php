<section class="posts col-md-9">
  <div class="miga-de-pan">
    <ol class="breadcrumb">
      <li><a href="#">Clasificados</a></li>
    </ol>
    <article class="post clearfix">
      <a href="#" class="thumb pull-left">
          <img class="img-thumbnail" src="<?php echo base_url() ."images/noticia1.jpg"; ?>" alt="">
          </a>
      <h2 class="post-title"><a href="#">Licey arremete contra las águilas por quita vez consecutiva.</a></h2>
      <p><span class="post-fecha">5 de diciembre del 2017 </span> por <span class="post-autor">Freilyn Rondon</span></p>
      <p class="post-contenido text-justify">
         Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae quidem blanditiis delectus corporis, possimus
         officia sint sequi ex tenetur id impedit est pariatur iure animi non a ratione reiciendis nihil sed consequatur
         atque repellendus fugit perspiciatis rerum et. Dolorum consequuntur fugit deleniti, soluta fuga nobis. Ducimus
         blanditiis velit sit iste delectus obcaecati debitis omnis, assumenda accusamus cumque perferendis eos aut quidem!
         Aut, totam rerum, cupiditate quae aperiam voluptas rem inventore quas, ex maxime culpa nam soluta labore at amet
         nihil laborum? Explicabo numquam, sit fugit, voluptatem autem atque quis quam voluptate fugiat earum rem hic,
         reprehenderit quaerat tempore at. Aperiam.
      </p>
      <div class="contenedor-botones">
        <a href="#" class="btn btn-primary">Leer Mas</a>
        <a href="#" class="btn btn-success">Comentarios<span class="badge">5</span></a>
      </div>
    </article>
    <article class="post clearfix">
      <a href="#" class="thumb pull-left">
          <img class="img-thumbnail" src="<?php echo base_url() ."images/noticia1.jpg"; ?>" alt="">
          </a>
      <h2 class="post-title"><a href="#">Licey arremete contra las águilas por quita vez consecutiva.</a></h2>
      <p><span class="post-fecha">5 de diciembre del 2017 </span> por <span class="post-autor">Freilyn Rondon</span></p>
      <p class="post-contenido text-justify">
         Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae quidem blanditiis delectus corporis, possimus
         officia sint sequi ex tenetur id impedit est pariatur iure animi non a ratione reiciendis nihil sed consequatur
         atque repellendus fugit perspiciatis rerum et. Dolorum consequuntur fugit deleniti, soluta fuga nobis. Ducimus
         blanditiis velit sit iste delectus obcaecati debitis omnis, assumenda accusamus cumque perferendis eos aut quidem!
         Aut, totam rerum, cupiditate quae aperiam voluptas rem inventore quas, ex maxime culpa nam soluta labore at amet
         nihil laborum? Explicabo numquam, sit fugit, voluptatem autem atque quis quam voluptate fugiat earum rem hic,
         reprehenderit quaerat tempore at. Aperiam.
      </p>
      <div class="contenedor-botones">
        <a href="#" class="btn btn-primary">Leer Mas</a>
        <a href="#" class="btn btn-success">Comentarios<span class="badge">5</span></a>
      </div>
    </article>
    <article class="post clearfix">
      <a href="#" class="thumb pull-left">
          <img class="img-thumbnail" src="<?php echo base_url() ."images/noticia1.jpg"; ?>" alt="">
          </a>
      <h2 class="post-title"><a href="#">Licey arremete contra las águilas por quita vez consecutiva.</a></h2>
      <p><span class="post-fecha">5 de diciembre del 2017 </span> por <span class="post-autor">Freilyn Rondon</span></p>
      <p class="post-contenido text-justify">
         Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae quidem blanditiis delectus corporis, possimus
         officia sint sequi ex tenetur id impedit est pariatur iure animi non a ratione reiciendis nihil sed consequatur
         atque repellendus fugit perspiciatis rerum et. Dolorum consequuntur fugit deleniti, soluta fuga nobis. Ducimus
         blanditiis velit sit iste delectus obcaecati debitis omnis, assumenda accusamus cumque perferendis eos aut quidem!
         Aut, totam rerum, cupiditate quae aperiam voluptas rem inventore quas, ex maxime culpa nam soluta labore at amet
         nihil laborum? Explicabo numquam, sit fugit, voluptatem autem atque quis quam voluptate fugiat earum rem hic,
         reprehenderit quaerat tempore at. Aperiam.
      </p>
      <div class="contenedor-botones">
        <a href="#" class="btn btn-primary">Leer Mas</a>
        <a href="#" class="btn btn-success">Comentarios<span class="badge">5</span></a>
      </div>
    </article>
    <article class="post clearfix">
      <a href="#" class="thumb pull-left">
          <img class="img-thumbnail" src="<?php echo base_url() ."images/noticia1.jpg"; ?>" alt="">
          </a>
      <h2 class="post-title"><a href="#">Licey arremete contra las águilas por quita vez consecutiva.</a></h2>
      <p><span class="post-fecha">5 de diciembre del 2017 </span> por <span class="post-autor">Freilyn Rondon</span></p>
      <p class="post-contenido text-justify">
         Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae quidem blanditiis delectus corporis, possimus
         officia sint sequi ex tenetur id impedit est pariatur iure animi non a ratione reiciendis nihil sed consequatur
         atque repellendus fugit perspiciatis rerum et. Dolorum consequuntur fugit deleniti, soluta fuga nobis. Ducimus
         blanditiis velit sit iste delectus obcaecati debitis omnis, assumenda accusamus cumque perferendis eos aut quidem!
         Aut, totam rerum, cupiditate quae aperiam voluptas rem inventore quas, ex maxime culpa nam soluta labore at amet
         nihil laborum? Explicabo numquam, sit fugit, voluptatem autem atque quis quam voluptate fugiat earum rem hic,
         reprehenderit quaerat tempore at. Aperiam.
      </p>
      <div class="contenedor-botones">
        <a href="#" class="btn btn-primary">Leer Mas</a>
        <a href="#" class="btn btn-success">Comentarios<span class="badge">5</span></a>
      </div>
    </article>
    <article class="post clearfix">
      <a href="#" class="thumb pull-left">
          <img class="img-thumbnail" src="<?php echo base_url() ."images/noticia1.jpg"; ?>" alt="">
          </a>
      <h2 class="post-title"><a href="#">Licey arremete contra las águilas por quita vez consecutiva.</a></h2>
      <p><span class="post-fecha">5 de diciembre del 2017 </span> por <span class="post-autor">Freilyn Rondon</span></p>
      <p class="post-contenido text-justify">
         Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae quidem blanditiis delectus corporis, possimus
         officia sint sequi ex tenetur id impedit est pariatur iure animi non a ratione reiciendis nihil sed consequatur
         atque repellendus fugit perspiciatis rerum et. Dolorum consequuntur fugit deleniti, soluta fuga nobis. Ducimus
         blanditiis velit sit iste delectus obcaecati debitis omnis, assumenda accusamus cumque perferendis eos aut quidem!
         Aut, totam rerum, cupiditate quae aperiam voluptas rem inventore quas, ex maxime culpa nam soluta labore at amet
         nihil laborum? Explicabo numquam, sit fugit, voluptatem autem atque quis quam voluptate fugiat earum rem hic,
         reprehenderit quaerat tempore at. Aperiam.
      </p>
      <div class="contenedor-botones">
        <a href="#" class="btn btn-primary">Leer Mas</a>
        <a href="#" class="btn btn-success">Comentarios<span class="badge">5</span></a>
      </div>
    </article>
    <nav>
      <div class="center-block">
        <ul class="pagination">
          <li class="disabled"><a href="#">&laquo;<span class="sr-only">Anterior</span></a></li>
          <li class="active"><a href="#">1</a></li>
          <li><a href="#">2</a></li>
          <li><a href="#">3</a></li>
          <li><a href="#">4</a></li>
          <li><a href="#">5</a></li>
          <li><a href="#">6</a></li>
          <li><a href="#">&raquo;<span class="sr-only">Siguiente</span></a></li>
        </ul>
      </div>
    </nav>
  </div>
</section>
