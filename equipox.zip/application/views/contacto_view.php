<!DOCTYPE html>
<div class="mbr-section__container mbr-section__container--std-padding container" style="padding-top: 93px; padding-bottom: 93px;">
  <div class="row">
      <div class="col-sm-12">
          <div class="row">
              <div class="col-sm-8 col-sm-offset-2">
                  <div class="mbr-header mbr-header--center mbr-header--std-padding">
                      <h2 class="mbr-header__text"><center>CONTACTO</center></h2>
                  </div>
                  <form method="post">
                      <div class="form-group">
                          <input type="text" class="form-control" name="name" required="" placeholder="Nombre*" >
                      </div>
                      <div class="form-group">
                          <input type="email" class="form-control" name="email" required="" placeholder="Correo electrónico*">
                      </div>

                      <div class="form-group">
                          <textarea class="form-control" name="message" rows="7" placeholder="Mensaje"></textarea>
                      </div>
                      <div>
                        <center><button type="submit" class="mbr-buttons__btn btn btn-lg btn-danger">CONTÁCTANOS</button></center>
                        </div>
                  </form>
              </div>
          </div>
      </div>
  </div>
</div>
