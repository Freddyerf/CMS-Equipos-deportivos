<script src="assets/js/modernizr.js"></script> <!-- Modernizr -->
<link rel="stylesheet" href="assets/css/style.css"> <!-- Resource style -->
<link rel="stylesheet" href="assets/css/reset.css"> <!-- CSS reset -->

<div class="container">
<section class="cd-faq">
<ul class="cd-faq-categories">
	<li><a class="selected" href="#basics">Basics</a></li>
	<li><a href="#mobile">Mobile</a></li>
	<li><a href="#account">Account</a></li>
	<li><a href="#payments">Payments</a></li>
</ul> <!-- cd-faq-categories -->

<div class="cd-faq-items">
	<ul id="basics" class="cd-faq-group">
		<li class="cd-faq-title"><h2>Basics</h2></li>
		<li>
			<a class="cd-faq-trigger" href="#0">How do I change my password?</a>
			<div class="cd-faq-content">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae quidem blanditiis delectus corporis, possimus officia sint sequi ex tenetur id impedit est pariatur iure animi non a ratione reiciendis nihil sed consequatur atque repellendus fugit perspiciatis rerum et. Dolorum consequuntur fugit deleniti, soluta fuga nobis. Ducimus blanditiis velit sit iste delectus obcaecati debitis omnis, assumenda accusamus cumque perferendis eos aut quidem! Aut, totam rerum, cupiditate quae aperiam voluptas rem inventore quas, ex maxime culpa nam soluta labore at amet nihil laborum? Explicabo numquam, sit fugit, voluptatem autem atque quis quam voluptate fugiat earum rem hic, reprehenderit quaerat tempore at. Aperiam.</p>
			</div> <!-- cd-faq-content -->
		</li>

		<li>
			<a class="cd-faq-trigger" href="#0">How do reviews work?</a>
			<div class="cd-faq-content">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis provident officiis, reprehenderit numquam. Praesentium veritatis eos tenetur magni debitis inventore fugit, magnam, reiciendis, saepe obcaecati ex vero quaerat distinctio velit.</p>
			</div> <!-- cd-faq-content -->
		</li>
	</ul> <!-- cd-faq-group -->

	<ul id="mobile" class="cd-faq-group">
		<li class="cd-faq-title"><h2>Mobile</h2></li>
		<li>
			<a class="cd-faq-trigger" href="#0">How does syncing work?</a>
			<div class="cd-faq-content">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Impedit quidem delectus rerum eligendi mollitia, repudiandae quae beatae. Et repellat quam atque corrupti iusto architecto impedit explicabo repudiandae qui similique aut iure ipsum quis inventore nulla error aliquid alias quia dolorem dolore, odio excepturi veniam odit veritatis. Quo iure magnam, et cum. Laudantium, eaque non? Tempore nihil corporis cumque dolor ipsum accusamus sapiente aliquid quis ea assumenda deserunt praesentium voluptatibus, accusantium a mollitia necessitatibus nostrum voluptatem numquam modi ab, sint rem.</p>
			</div> <!-- cd-faq-content -->
		</li>

		<li>
			<a class="cd-faq-trigger" href="#0">How do I upload files from my phone or tablet?</a>
			<div class="cd-faq-content">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nisi tempore, placeat quisquam rerum! Eligendi fugit dolorum tenetur modi fuga nisi rerum, autem officiis quaerat quos. Magni quia, quo quibusdam odio. Error magni aperiam amet architecto adipisci aspernatur! Officia, quaerat magni architecto nostrum magnam fuga nihil, ipsum laboriosam similique voluptatibus facilis nobis? Eius non asperiores, nesciunt suscipit veniam blanditiis veritatis provident possimus iusto voluptas, eveniet architecto quidem quos molestias, aperiam eum reprehenderit dolores ad deserunt eos amet. Vero molestiae commodi unde dolor dicta maxime alias, velit, nesciunt cum dolorem, ipsam soluta sint suscipit maiores mollitia assumenda ducimus aperiam neque enim! Quas culpa dolorum ipsam? Ipsum voluptatibus numquam natus? Eligendi explicabo eos, perferendis voluptatibus hic sed ipsam rerum maiores officia! Beatae, molestias!</p>
			</div> <!-- cd-faq-content -->
		</li>
	</ul> <!-- cd-faq-group -->

	<ul id="account" class="cd-faq-group">
		<li class="cd-faq-title"><h2>Account</h2></li>
		<li>
			<a class="cd-faq-trigger" href="#0">How do I change my password?</a>
			<div class="cd-faq-content">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis earum autem consectetur labore eius tenetur esse, in temporibus sequi cum voluptatem vitae repellat nostrum odio perspiciatis dolores recusandae necessitatibus, unde, deserunt voluptas possimus veniam magni soluta deleniti! Architecto, quidem, totam. Fugit minus odit unde ea cupiditate ab aperiam sed dolore facere nihil laboriosam dolorum repellat deleniti aliquam fugiat laudantium delectus sint iure odio, necessitatibus rem quisquam! Ipsum praesentium quam nisi sint, impedit sapiente facilis laudantium mollitia quae fugiat similique. Dolor maiores aliquid incidunt commodi doloremque rem! Quaerat, debitis voluptatem vero qui enim, sunt reiciendis tempore inventore maxime quasi fugiat accusamus beatae modi voluptates iste officia esse soluta tempora labore quisquam fuga, cum. Sint nemo iste nulla accusamus quam qui quos, vero, minus id. Eius mollitia consequatur fugit nam consequuntur nesciunt illo id quis reprehenderit obcaecati voluptates corrupti, minus! Possimus, perspiciatis!</p>
			</div> <!-- cd-faq-content -->
		</li>

		<li>
			<a class="cd-faq-trigger" href="#0">I forgot my password. How do I reset it?</a>
			<div class="cd-faq-content">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsum at aspernatur iure facere ab a corporis mollitia molestiae quod omnis minima, est labore quidem nobis accusantium ad totam sunt doloremque laudantium impedit similique iste quasi cum! Libero fugit at praesentium vero. Maiores non consequuntur rerum, nemo a qui repellat quibusdam architecto voluptatem? Sequi, possimus, cupiditate autem soluta ipsa rerum officiis cum libero delectus explicabo facilis, odit ullam aperiam reprehenderit! Vero ad non harum veritatis tempore beatae possimus, ex odio quo.</p>
			</div> <!-- cd-faq-content -->
		</li>
	</ul> <!-- cd-faq-group -->

	<ul id="payments" class="cd-faq-group">
		<li class="cd-faq-title"><h2>Payments</h2></li>
		<li>
			<a class="cd-faq-trigger" href="#0">Can I have an invoice for my subscription?</a>
			<div class="cd-faq-content">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Impedit quidem delectus rerum eligendi mollitia, repudiandae quae beatae. Et repellat quam atque corrupti iusto architecto impedit explicabo repudiandae qui similique aut iure ipsum quis inventore nulla error aliquid alias quia dolorem dolore, odio excepturi veniam odit veritatis. Quo iure magnam, et cum. Laudantium, eaque non? Tempore nihil corporis cumque dolor ipsum accusamus sapiente aliquid quis ea assumenda deserunt praesentium voluptatibus, accusantium a mollitia necessitatibus nostrum voluptatem numquam modi ab, sint rem.</p>
			</div> <!-- cd-faq-content -->
		</li>

		<li>
			<a class="cd-faq-trigger" href="#0">Why did my credit card or PayPal payment fail?</a>
			<div class="cd-faq-content">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur accusantium dolorem vel, ad, nostrum natus eos, nemo placeat quos nisi architecto rem dolorum amet consectetur molestiae reprehenderit cum harum commodi beatae necessitatibus. Mollitia a nostrum enim earum minima doloribus illum autem, provident vero et, aspernatur quae sunt illo dolorem. Corporis blanditiis, unde, neque, adipisci debitis quas ullam accusantium repudiandae eum nostrum quis! Velit esse harum qui, modi ratione debitis alias laboriosam minus eaque, quod, itaque labore illo totam aut quia fuga nemo. Perferendis ipsa laborum atque assumenda tempore aspernatur a eos harum non id commodi excepturi quaerat ullam, explicabo, incidunt ipsam, accusantium quo magni ut! Ratione, magnam. Delectus nesciunt impedit praesentium sed, aliquam architecto dolores quae, distinctio consectetur obcaecati esse, consequuntur vel sit quis blanditiis possimus dolorum. Eaque architecto doloremque aliquid quae cumque, vitae perferendis enim, iure fugiat, soluta aut!</p>
			</div> <!-- cd-faq-content -->
		</li>

		<li>
			<a class="cd-faq-trigger" href="#0">Why does my bank statement show multiple charges for one upgrade?</a>
			<div class="cd-faq-content">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis provident officiis, reprehenderit numquam. Praesentium veritatis eos tenetur magni debitis inventore fugit, magnam, reiciendis, saepe obcaecati ex vero quaerat distinctio velit.</p>
			</div> <!-- cd-faq-content -->
		</li>
	</ul> <!-- cd-faq-group -->

</div> <!-- cd-faq-items -->

</section> <!-- cd-faq -->
</div>
<script src="assets/js/jquery-2.1.1.js"></script>
<script src="assets/js/jquery.mobile.custom.min.js"></script>
<script src="assets/js/main.js"></script> <!-- Resource jQuery -->
