<div class="container">
  <div class="row">
    <div class="col-xs-6 col-md-3">
      <a href="#" class="thumbnail"><img src="<?php echo base_url() .'images/galeria/noticia2.jpg'; ?>" alt=""></a>
    </div>
    <div class="col-xs-6 col-md-3">
      <a href="#" class="thumbnail"><img src="<?php echo base_url() .'images/galeria/noticia3.jpg'; ?>" alt=""></a>
    </div>
    <div class="col-xs-6 col-md-3">
      <a href="#" class="thumbnail"><img src="<?php echo base_url() .'images/galeria/noticia4.jpg'; ?>" alt=""></a>
    </div>
    <div class="col-xs-6 col-md-3">
      <a href="#" class="thumbnail"><img src="<?php echo base_url() .'images/galeria/noticia5.jpg'; ?>" alt=""></a>
    </div>
  </div>
  <div class="row">
    <div class="col-xs-6 col-md-3">
      <a href="#" class="thumbnail"><img src="<?php echo base_url() .'images/galeria/noticia6.jpg'; ?>" alt=""></a>
    </div>
    <div class="col-xs-6 col-md-3">
      <a href="#" class="thumbnail"><img src="<?php echo base_url() .'images/galeria/noticia7.jpg'; ?>" alt=""></a>
    </div>
    <div class="col-xs-6 col-md-3">
      <a href="#" class="thumbnail"><img src="<?php echo base_url() .'images/galeria/noticia8.jpg'; ?>" alt=""></a>
    </div>
    <div class="col-xs-6 col-md-3">
      <a href="#" class="thumbnail"><img src="<?php echo base_url() .'images/galeria/noticia9.jpg'; ?>" alt=""></a>
    </div>
  </div>
  <div class="row">
    <div class="col-xs-6 col-md-3">
      <a href="#" class="thumbnail"><img src="<?php echo base_url() .'images/galeria/noticia10.jpg'; ?>" alt=""></a>
    </div>
    <div class="col-xs-6 col-md-3">
      <a href="#" class="thumbnail"><img src="<?php echo base_url() .'images/galeria/noticia11.jpg'; ?>" alt=""></a>
    </div>
    <div class="col-xs-6 col-md-3">
      <a href="#" class="thumbnail"><img src="<?php echo base_url() .'images/galeria/noticia12.jpg'; ?>" alt=""></a>
    </div>
    <div class="col-xs-6 col-md-3">
      <a href="#" class="thumbnail"><img src="<?php echo base_url() .'images/galeria/noticia13.jpg'; ?>" alt=""></a>
    </div>
  </div>

</div>
